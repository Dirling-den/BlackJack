#ifndef GAME_H
#define GAME_H

#include <vector>
#include <string>
#include <random>

struct Card {
    std::string rank;
    std::string suit;

    Card() = default;
    Card(const std::string& r, const std::string& s) : rank(r), suit(s) {}
};

class Deck {
private:
    std::vector<Card> cards;
    std::mt19937 rng;

public:
    Deck();

    void reset();
    void shuffle();
    Card deal();
    bool empty() const;
    size_t size() const;
};

class Hand {
private:
    std::vector<Card> cards;

public:
    void addCard(const Card& card);
    int getValue() const;
    void clear();
    const std::vector<Card>& getCards() const;
};

class Game {
private:
    Deck deck;
    Hand player;
    Hand dealer;

    void showHands(bool hideDealerCard) const;
    bool playerTurn();
    bool dealerTurn();
    int compareHands() const;

public:
    Game();

    void start();
};

#endif