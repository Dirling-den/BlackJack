#include "game.h"

#include <iostream>
#include <algorithm>
#include <limits>

Card::Card() : rank(""), suit("") {}

Card::Card(const std::string& r, const std::string& s) : rank(r), suit(s) {}

Deck::Deck() {
    std::random_device rd;
    rng = std::mt19937(rd());
    reset();
    shuffle();
}

void Deck::reset() {
    cards.clear();

    const std::vector<std::string> suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
    const std::vector<std::string> ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

    for (const auto& suit : suits) {
        for (const auto& rank : ranks) {
            cards.emplace_back(rank, suit);
        }
    }
}

void Deck::shuffle() {
    std::shuffle(cards.begin(), cards.end(), rng);
}

Card Deck::deal() {
    if (cards.empty()) {
        reset();
        shuffle();
    }

    Card card = cards.back();
    cards.pop_back();
    return card;
}

bool Deck::empty() const {
    return cards.empty();
}

std::size_t Deck::size() const {
    return cards.size();
}

Hand::Hand() = default;

void Hand::addCard(const Card& card) {
    cards.push_back(card);
}

int Hand::getValue() const {
    int total = 0;
    int aces = 0;

    for (const auto& card : cards) {
        if (card.rank == "A") {
            total += 11;
            ++aces;
        } else if (card.rank == "K" || card.rank == "Q" || card.rank == "J") {
            total += 10;
        } else {
            total += std::stoi(card.rank);
        }
    }

    while (total > 21 && aces > 0) {
        total -= 10;
        --aces;
    }

    return total;
}

void Hand::clear() {
    cards.clear();
}

const std::vector<Card>& Hand::getCards() const {
    return cards;
}

std::size_t Hand::size() const {
    return cards.size();
}

Game::Game() = default;

void Game::showHands(bool hideDealerCard) const {
    std::cout << "\nDealer hand:\n";
    const auto& dealerCards = dealer.getCards();

    for (std::size_t i = 0; i < dealerCards.size(); ++i) {
        if (hideDealerCard && i == 0) {
            std::cout << "[Hidden]\n";
        } else {
            std::cout << dealerCards[i].rank << " of " << dealerCards[i].suit << "\n";
        }
    }

    if (hideDealerCard) {
        std::cout << "Dealer total: ?\n";
    } else {
        std::cout << "Dealer total: " << dealer.getValue() << "\n";
    }

    std::cout << "\nPlayer hand:\n";
    for (const auto& card : player.getCards()) {
        std::cout << card.rank << " of " << card.suit << "\n";
    }
    std::cout << "Player total: " << player.getValue() << "\n";
}

bool Game::playerTurn() {
    while (true) {
        showHands(true);

        if (player.getValue() > 21) {
            std::cout << "You busted!\n";
            return false;
        }

        std::cout << "\nHit or stand? (h/s): ";
        char choice;
        std::cin >> choice;

        if (choice == 'h' || choice == 'H') {
            player.addCard(deck.deal());
        } else if (choice == 's' || choice == 'S') {
            return true;
        } else {
            std::cout << "Invalid input.\n";
        }
    }
}

bool Game::dealerTurn() {
    std::cout << "\nDealer turn...\n";

    while (dealer.getValue() < 17) {
        dealer.addCard(deck.deal());
        showHands(false);
    }

    if (dealer.getValue() > 21) {
        std::cout << "Dealer busted!\n";
        return false;
    }

    return true;
}

int Game::compareHands() const {
    int playerValue = player.getValue();
    int dealerValue = dealer.getValue();

    if (playerValue > 21) return -1;
    if (dealerValue > 21) return 1;
    if (playerValue > dealerValue) return 1;
    if (playerValue < dealerValue) return -1;
    return 0;
}

void Game::start() {
    deck.reset();
    deck.shuffle();
    player.clear();
    dealer.clear();

    player.addCard(deck.deal());
    dealer.addCard(deck.deal());
    player.addCard(deck.deal());
    dealer.addCard(deck.deal());

    std::cout << "=== Blackjack ===\n";

    bool playerAlive = playerTurn();
    if (!playerAlive) {
        showHands(false);
        std::cout << "Dealer wins!\n";
        return;
    }

    bool dealerAlive = dealerTurn();
    showHands(false);

    if (!dealerAlive) {
        std::cout << "You win!\n";
        return;
    }

    int result = compareHands();
    if (result > 0) {
        std::cout << "You win!\n";
    } else if (result < 0) {
        std::cout << "Dealer wins!\n";
    } else {
        std::cout << "Push! It's a tie.\n";
    }
}