#include <iostream>
#include "game.h"

int main() {
    char choice;
    do {
        Game game;
        game.start();

        std::cout << "Play again? (y/n): ";
        std::cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    return 0;
}